<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Nerytec</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheest" href="assets/css/CanitoFormularioCompra2.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Pretty-Search-Form.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <form>
    	<body>
            <header>    
                <a href="choix.php">
                    <img src="assets/img/NerytecLogo.jpg" />
</a>
            </header>
		
	</body>

</form>

    <br>
    <br>
    <form></form>
    
    <div class="row">
  <div class="col-lg-12">
    <div class="text-center">
        
        <form action="Afficher.php">
            <button class="btn btn-primary" id="singlebutton" > Afficher rappel</button>
            
        </form>
    <br>
            <form action="ChercherCV.php">
            <button class="btn btn-primary" id="singlebutton" > Chercher CV</button>
            
        </form>
    <br>
        <form action="Ajouter.php">
            <button class="btn btn-primary" id="singlebutton"> Ajouter un CV </button>
            
        </form>
      
        
        
    </div>
  </div>
</div>
    
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>


</html>
<?php


?>


