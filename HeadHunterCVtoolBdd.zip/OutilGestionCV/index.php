<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Nerytec</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/CanitoFormularioCompra2.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Pretty-Search-Form.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
            <form action="loginFonction.php" method="POST"> 
    <div class="login-clean">
        <div class="login-card"><img class="profile-img-card" src="assets/img/NerytecLogo.jpg">
            <p class="profile-name-card"> </p>
            <form class="form-signin"><span class="reauth-email"> </span>
                <input class="form-control" type="iden" id="inputIden" name="Identifiant" required="" placeholder="Identifiant" autofocus="">
                <input class="form-control" type="password" id="inputPassword" name="Mot_De_Passe" required="" placeholder="Mot de passe">
                <div
                    class="checkbox"></div>
                                <button name="submit" class="btn btn-primary btn-block" type="submit">Entrez </button>
            </form>
    </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>